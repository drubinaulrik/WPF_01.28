﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Homerseklet_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public class Homerseklet
        {
            public int honap { get; set; }
            public int nap { get; set; }
            public int min { get; set; }
            public int max { get; set; }

            public Homerseklet(string sor)
            {
                string[] t = sor.Split(';');
                honap = int.Parse(t[0]);
                nap = int.Parse(t[1]);
                min = int.Parse(t[2]);
                max = int.Parse(t[3]);
            }
        }

        List<Homerseklet> homerseklet = new List<Homerseklet>();
        public MainWindow()
        {
            InitializeComponent();
            foreach(var i in File.ReadAllLines("homerseklet.txt").Skip(1))
            {
                homerseklet.Add(new Homerseklet(i));
            }
        }

        private void Betölt_Click(object sender, RoutedEventArgs e)
        {
            lista.Items.Clear();
            foreach (var i in homerseklet)
            {
                lista.Items.Add(i.honap+"\t"+i.nap+"\t"+i.min+"\t"+i.max);
            }
        }

        private void evi_Click(object sender, RoutedEventArgs e)
        {
            lista.Items.Clear();
        }

        private void havi_Click(object sender, RoutedEventArgs e)
        {
            lista.Items.Clear();
        }

        private void feletti_Click(object sender, RoutedEventArgs e)
        {
            lista.Items.Clear();
        }
    }
}